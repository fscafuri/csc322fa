const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000); // Square aspect ratio
const renderer = new THREE.WebGLRenderer();

// Ensure the canvas dimensions are between 500x500 and 800x800 pixels
const canvasSize = Math.max(500, Math.min(800, Math.min(window.innerWidth, window.innerHeight)));

renderer.setSize(canvasSize, canvasSize);
document.body.appendChild(renderer.domElement);

camera.position.z = 5;

//sky
function sky() {
  const geometrysky = new THREE.BoxGeometry(9, 9, 0);
  const materialsky = new THREE.MeshBasicMaterial({
    color: 0x87CEEB
  });
  const sky = new THREE.Mesh(geometrysky, materialsky);
  scene.add(sky);
}

//sun
function sun() {
  const geometrysun = new THREE.CircleGeometry(.5, 32);
  const materialsun = new THREE.MeshBasicMaterial({
    color: "yellow"
  }); // Yellow color
  const sun = new THREE.Mesh(geometrysun, materialsun);

  sun.position.set(3, 3, 0);
  scene.add(sun);
}

//grass
function grass() {
  const geometrygrass = new THREE.BoxGeometry(8, 2, 0);
  const materialgrass = new THREE.MeshBasicMaterial({
    color: 0x41980a
  });
  const grass = new THREE.Mesh(geometrygrass, materialgrass);
  grass.position.set(0, -2.3, 2);
  scene.add(grass);
}

//back mountain
function backMountain() {
  const backgeometry = new THREE.BufferGeometry();
  const backvertices = new Float32Array([
    -2.0, -2, 0, // v0
    2.0, -2, 0, // v1
    0, 2.5, 0, // v2

  ]);
  backgeometry.setAttribute('position', new THREE.BufferAttribute(backvertices, 3));
  const backmaterial = new THREE.MeshBasicMaterial({
    color: Math.random() * 0xffffff
  });
  const back = new THREE.Mesh(backgeometry, backmaterial);
  scene.add(back);

}

//left mountain
function left() {
  const leftgeometry = new THREE.BufferGeometry();
  const leftvertices = new Float32Array([
    -4.0, -2, 1, // v0
    1.0, -2, 1, // v1
    -1.5, 1.0, 1, // v2

  ]);
  leftgeometry.setAttribute('position', new THREE.BufferAttribute(leftvertices, 3));
  const leftmaterial = new THREE.MeshBasicMaterial({
    color: Math.random() * 0xffffff
  });
  const left = new THREE.Mesh(leftgeometry, leftmaterial);
  scene.add(left);
}

//right mountain
function right() {
  const rightgeometry = new THREE.BufferGeometry();
  const rightvertices = new Float32Array([
    -1.0, -2, 1.5, // v0
    4.0, -2, 1.5, // v1
    1.5, 1.0, 1.5, // v2

  ]);
  rightgeometry.setAttribute('position', new THREE.BufferAttribute(rightvertices, 3));
  const rightmaterial = new THREE.MeshBasicMaterial({
    color: Math.random() * 0xffffff
  });
  const right = new THREE.Mesh(rightgeometry, rightmaterial);
  scene.add(right);
}

//blades
function blades() {
  let count = -3.0;
  for (let i = 0; i < 40; i++) {
    const geometryblade = new THREE.BoxGeometry(0.1, 1, 0);
    const materialblade = new THREE.MeshBasicMaterial({
      color: 0x41980a
    });
    const blade = new THREE.Mesh(geometryblade, materialblade);
    blade.position.set(count, -1.4, 2);
    scene.add(blade);
    count = count + 0.2;
  }
}

//tree
function tree() {
  const geometrytrunk = new THREE.BoxGeometry(0.2, 0.75, 0);
  const materialtrunk = new THREE.MeshBasicMaterial({
    color: "brown"
  });
  const trunk = new THREE.Mesh(geometrytrunk, materialtrunk);
  trunk.position.set(1.5, -1.5, 2);
  scene.add(trunk);


  const ellipseGeometry = new THREE.ShapeGeometry(new THREE.Shape().ellipse(0, 0, 0.3, 0.5, 0, Math.PI * 2));
  const ellipseMaterial = new THREE.MeshBasicMaterial({
    color: 0x206113,
    side: THREE.DoubleSide
  });
  const ellipseMesh = new THREE.Mesh(ellipseGeometry, ellipseMaterial);

  ellipseMesh.position.set(1.5, -0.75, 2);

  scene.add(ellipseMesh);
}

function createBird(i) {
  const material = new THREE.LineBasicMaterial({
    color: "black",
    linewidth: 10
  });
  const points = [];
  points.push(new THREE.Vector3(0.1, 0.1, 0));
  points.push(new THREE.Vector3(0, 0, 0));
  points.push(new THREE.Vector3(-0.1, 0.1, 0));

  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const line = new THREE.Line(geometry, material);
  line.position.set(i, Math.random(0, 5), 1.5);
  scene.add(line);
  return line;


}

function motion() {

  // Store the initial mouse position
  let mouseX = 0;
  let mouseY = 0;

  // Handle mouse movement
  document.addEventListener('mousemove', (event) => {
    mouseX = (event.clientX / window.innerWidth) * 2 - 1;
    mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
  });

  // Render loop
  function animate() {
    requestAnimationFrame(animate);

    // Update camera position based on mouse movement
    const parallaxStrength = 0.6;
    camera.position.x = mouseX * parallaxStrength;
    camera.position.y = mouseY * parallaxStrength;

    camera.lookAt(mouseX*parallaxStrength, mouseY*parallaxStrength, 5);
  }
  animate();
}

function bench(){
	const geometryseat = new THREE.BoxGeometry(0.75, 0.2, 0);
  const materialseat = new THREE.MeshBasicMaterial({
    color: 0x6F5339
  });
  const seat = new THREE.Mesh(geometryseat, materialseat);
  seat.position.set(-1.5, -1.5, 2);
  scene.add(seat);
  const geometryleg1 = new THREE.BoxGeometry(0.1, 0.3, 0);
  const materialleg1 = new THREE.MeshBasicMaterial({
    color: 0x6F5339
  });
  const leg1 = new THREE.Mesh(geometryleg1, materialleg1);
  leg1.position.set(-1.79,-1.75,2);
  scene.add(leg1);
  const geometryleg2 = new THREE.BoxGeometry(0.1, 0.3, 0);
  const materialleg2 = new THREE.MeshBasicMaterial({
    color: 0x6F5339
  });
  const leg2 = new THREE.Mesh(geometryleg2, materialleg2);
  leg2.position.set(-1.21,-1.75,2);
  scene.add(leg2)
}




function createscene() {
  sky();
  sun();
  grass();
  backMountain();
  left();
  right();
  blades();
  tree();
  // Create 5 birds
  let i = -2;
  const birds = [];
  while (i < 3) {
    birds.push(createBird(i));
    i++;
  }

  function animate() {
    requestAnimationFrame(animate);

    // Update the position of each bird
    birds.forEach(bird => {
      bird.position.x += 0.02; // Move the bird to the right

      // If the bird goes off the screen, reset its position to the left
      if (bird.position.x > 3) {
        bird.position.x = -3;
        bird.position.y = Math.random(0, 5);
      }
    });

    renderer.render(scene, camera);
  }
  animate();
  motion();
  bench();

}

createscene();


renderer.render(scene, camera);
